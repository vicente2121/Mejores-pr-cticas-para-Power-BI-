// Referencias necesarias
#r "System.Net.Http"

using System;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;  
using Newtonsoft.Json.Linq;

public class Program
{
    // Configuración de la API
    const string apiKey = "apikey";
    const string deploymentName = "gpt-4";
    const string AzureOpenaiEndpoint = "AzureOpenaiEndpoint";
    const string url = AzureOpenaiEndpoint + "openai/deployments/" + deploymentName + "/chat/completions?api-version=2024-05-01-preview";

    // Preguntas base
    const string questionTable = "Explain the following table in Spanish in a few sentences in simple business terms: \n\n";
    const string questionMeasure = "Explain the following calculation in Spanish in a few sentences in simple business terms without using DAX function names: \n\n";
    const string questionTableColumns = "Explain the following column in Spanish in a few sentences in simple business terms: \n\n";

    static async Task Main(string[] args)
    {
        int contar = 0;
        const int requestLimit = 30;
        const bool processTables = true;
        const bool processMeasures = true;
        const bool processColumns = true;

        using (var client = new HttpClient())
        {
            client.DefaultRequestHeaders.Clear();
            client.DefaultRequestHeaders.Add("api-key", apiKey);

            foreach (var t in Model.Tables) // Iterar sobre las tablas del modelo
            {
                if (processTables)
                {
                    contar = await ProcessTablesAsync(client, t, contar, requestLimit);
                }

                if (processMeasures)
                {
                    contar = await ProcessMeasuresAsync(client, t, contar, requestLimit);
                }

                if (processColumns)
                {
                    contar = await ProcessColumnsAsync(client, t, contar, requestLimit);
                }
            }
        }
    }

    private static async Task<int> ProcessTablesAsync(HttpClient client, dynamic table, int contar, int requestLimit)
    {
        if (table.Description == "")
        {
            try
            {
                string body = JsonConvert.SerializeObject(new
                {
                    messages = new[] {
                        new { role = "user", content = questionTable + table.Name }
                    }
                });

                if (contar == requestLimit)
                {
                    contar = 0;
                    Thread.Sleep(10000);
                }

                var response = await client.PostAsync(url, new StringContent(body, Encoding.UTF8, "application/json"));
                response.EnsureSuccessStatusCode();

                var result = await response.Content.ReadAsStringAsync();
                var desc = JObject.Parse(result)["choices"][0]["message"]["content"].ToString().Trim();

                table.Description = desc;
                contar++;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error processing table {table.Name}: {ex.Message}");
            }
        }

        return contar;
    }

    private static async Task<int> ProcessMeasuresAsync(HttpClient client, dynamic table, int contar, int requestLimit)
    {
        foreach (var measure in table.Measures)
        {
            if (measure.Description == "")
            {
                try
                {
                    string body = JsonConvert.SerializeObject(new
                    {
                        messages = new[] {
                            new { role = "user", content = questionMeasure + measure.Expression.Replace("\"", "'") }
                        }
                    });

                    if (contar == requestLimit)
                    {
                        contar = 0;
                        Thread.Sleep(10000);
                    }

                    var response = await client.PostAsync(url, new StringContent(body, Encoding.UTF8, "application/json"));
                    response.EnsureSuccessStatusCode();

                    var result = await response.Content.ReadAsStringAsync();
                    var desc = JObject.Parse(result)["choices"][0]["message"]["content"].ToString().Trim();

                    measure.Description = desc;
                    contar++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing measure {measure.Name}: {ex.Message}");
                }
            }
        }

        return contar;
    }

    private static async Task<int> ProcessColumnsAsync(HttpClient client, dynamic table, int contar, int requestLimit)
    {
        foreach (var column in table.Columns)
        {
            if (column.Description == "")
            {
                try
                {
                    string body = JsonConvert.SerializeObject(new
                    {
                        messages = new[] {
                            new { role = "user", content = questionTableColumns + table.Name + " - " + column.Name }
                        }
                    });

                    if (contar == requestLimit)
                    {
                        contar = 0;
                        Thread.Sleep(10000);
                    }

                    var response = await client.PostAsync(url, new StringContent(body, Encoding.UTF8, "application/json"));
                    response.EnsureSuccessStatusCode();

                    var result = await response.Content.ReadAsStringAsync();
                    var desc = JObject.Parse(result)["choices"][0]["message"]["content"].ToString().Trim();

                    column.Description = desc;
                    contar++;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing column {column.Name}: {ex.Message}");
                }
            }
        }

        return contar;
    }
}

// Simulación de un modelo de datos dinámico
public static class Model
{
    public static dynamic Tables = new[]
    {
        new {
            Name = "Sales",
            Description = "",
            Measures = new[]
            {
                new { Name = "Total Sales", Description = "", Expression = "SUM(Sales[Amount])" }
            },
            Columns = new[]
            {
                new { Name = "Date", Description = "" },
                new { Name = "Amount", Description = "" }
            }
        }
    };
}
